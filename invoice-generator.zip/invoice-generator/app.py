from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload
from google.oauth2.service_account import Credentials
from flask import Flask, render_template, request, send_file
import os
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Spacer
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import Paragraph
from datetime import datetime
from reportlab.lib.pagesizes import A5

# Google Drive API Setup
DRIVE_SCOPES = ["https://www.googleapis.com/auth/drive"]
drive_creds = Credentials.from_service_account_file("credentials.json", scopes=DRIVE_SCOPES)
drive_service = build("drive", "v3", credentials=drive_creds)

def create_drive_folder(folder_name):
    """
    Creates a folder in Google Drive if it doesn't already exist.
    Returns the folder ID.
    """
    # Check if the folder already exists
    response = drive_service.files().list(
        q=f"mimeType='application/vnd.google-apps.folder' and name='{folder_name}'",
        spaces="drive",
        fields="files(id, name)",
    ).execute()

    folders = response.get("files", [])
    if folders:
        return folders[0]["id"]  # Return the first folder's ID if it exists

    # Create a new folder
    file_metadata = {
        "name": folder_name,
        "mimeType": "application/vnd.google-apps.folder",
    }
    folder = drive_service.files().create(body=file_metadata, fields="id").execute()
    return folder["id"]

def upload_to_drive(folder_id, filename, file_buffer):
    """
    Uploads a file to a specified folder in Google Drive.
    """
    # Create MediaIoBaseUpload for the file buffer
    media = MediaIoBaseUpload(file_buffer, mimetype="application/pdf", resumable=True)
    
    # Set metadata for the file (name and parent folder)
    file_metadata = {
        "name": filename,
        "parents": [folder_id],
    }

    # Upload the file
    drive_service.files().create(body=file_metadata, media_body=media, fields="id").execute()
    

app = Flask(__name__)

# Google Sheets API Setup
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("credentials.json", scope)
client = gspread.authorize(creds)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate_invoice():
    date = request.form["date"]
    buyer_name = request.form["buyerName"]
    product_names = request.form.getlist("productName[]")
    quantities = request.form.getlist("quantity[]")
    prices = request.form.getlist("price[]")

    # Calculate amounts
    total_amount = 0
    items = []
    for i in range(len(product_names)):
        amount = int(quantities[i]) * float(prices[i])
        total_amount += amount
        items.append((i + 1, product_names[i], quantities[i], prices[i], amount))

    # Save to Google Sheets
    try:
        spreadsheet = client.open("InvoiceRecords")
    except gspread.exceptions.SpreadsheetNotFound:
        return "Spreadsheet 'InvoiceRecords' not found or not shared with the service account.", 404

    try:
        sheet = spreadsheet.worksheet(buyer_name)
    except gspread.exceptions.WorksheetNotFound:
        sheet = spreadsheet.add_worksheet(title=buyer_name, rows="100", cols="20")

    if len(sheet.get_all_values()) == 0:
        sheet.append_row(["Date", "Product Name", "Quantity", "Amount"])
    

    for item in items:
        formatted_date = datetime.strptime(date, "%Y-%m-%d").strftime("%d-%m-%Y")
        sheet.append_row([formatted_date, item[1], item[2], item[4]])

    # Generate PDF
    buffer = BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=A5)

    # Convert the date format to DD-MM-YYYY
    formatted_date = datetime.strptime(date, "%Y-%m-%d").strftime("%d-%m-%Y")

    # Constants
    PAGE_WIDTH, PAGE_HEIGHT = A5
    MARGIN = 30  # Reduced margin for more table space
    TABLE_START_Y = PAGE_HEIGHT - 150  # Starting Y position of the table
    ROW_HEIGHT = 20
    FOOTER_HEIGHT = 40

    # Dynamically calculated column widths based on A5 page size
    TABLE_COLUMNS = [
        MARGIN,  # NO
        MARGIN + 40,  # PRODUCT NAME
        MARGIN + 200,  # QTY
        MARGIN + 250,  # RATE/PCS
        MARGIN + 320,  # AMOUNT
    ]

    def draw_border():
        """Draws a border around the page."""
        pdf.setLineWidth(1)  # Border thickness
        pdf.rect(MARGIN - 10, MARGIN - 10, PAGE_WIDTH - 2 * (MARGIN - 10), PAGE_HEIGHT - 2 * (MARGIN - 10))

    def draw_header():
        """Draws the header."""
        y = TABLE_START_Y
        pdf.setFont("Helvetica", 10)
        pdf.drawCentredString(PAGE_WIDTH / 2, PAGE_HEIGHT - 40, "Estimate")
        pdf.setFont("Helvetica-Bold", 16)
        pdf.drawCentredString(PAGE_WIDTH / 2, PAGE_HEIGHT - 60, "Sun Enterprises")
        pdf.setFont("Helvetica", 10)
        y_buyer_date = PAGE_HEIGHT - 90
       # Set font for "BILL TO" and "DATE" as bold
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawString(MARGIN, y_buyer_date, "BILL TO:")
        pdf.drawRightString(PAGE_WIDTH - MARGIN-60, y_buyer_date, "DATE:")

        # Set font back to normal for the buyer name and date values
        pdf.setFont("Helvetica", 10)
        pdf.drawString(MARGIN +50 , y_buyer_date, buyer_name)  # Add spacing after "BILL TO:"
        pdf.drawRightString(PAGE_WIDTH - MARGIN, y_buyer_date, formatted_date)
        pdf.line(MARGIN, y + ROW_HEIGHT - 5, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT - 5)

    def draw_table():
        """Draws the table containing the product details."""
        y = TABLE_START_Y

        # Table header
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawString(TABLE_COLUMNS[0], y, "NO")
        pdf.drawString(TABLE_COLUMNS[1], y, "PRODUCT NAME")
        pdf.drawString(TABLE_COLUMNS[2], y, "QTY")
        pdf.drawString(TABLE_COLUMNS[3], y, "RATE/PCS")
        pdf.drawString(TABLE_COLUMNS[4], y, "AMOUNT")
        y -= ROW_HEIGHT
        pdf.line(MARGIN, y + ROW_HEIGHT - 5, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT - 5)

        # Table rows
        pdf.setFont("Helvetica", 10)
        for idx, item in enumerate(items, start=1):
            if y < FOOTER_HEIGHT + ROW_HEIGHT:  # Start a new page if content overflows
                draw_footer()
                pdf.showPage()
                draw_border()
                draw_header()
                y = TABLE_START_Y
                pdf.setFont("Helvetica-Bold", 10)
                pdf.drawString(TABLE_COLUMNS[0], y, "NO")
                pdf.drawString(TABLE_COLUMNS[1], y, "PRODUCT NAME")
                pdf.drawString(TABLE_COLUMNS[2], y, "QTY")
                pdf.drawString(TABLE_COLUMNS[3], y, "RATE/PCS")
                pdf.drawString(TABLE_COLUMNS[4], y, "AMOUNT")
                y -= ROW_HEIGHT
                pdf.line(MARGIN, y + ROW_HEIGHT - 5, PAGE_WIDTH - MARGIN, y + ROW_HEIGHT - 5)

            pdf.drawString(TABLE_COLUMNS[0], y, str(idx))
            pdf.drawString(TABLE_COLUMNS[1], y, item[1])
            pdf.drawRightString(TABLE_COLUMNS[2]+20, y, str(item[2]))
            pdf.drawRightString(TABLE_COLUMNS[3]+20, y, f"{item[3]}")
            pdf.drawRightString(TABLE_COLUMNS[4]+30, y, f"{item[4]}")
            y -= ROW_HEIGHT

        pdf.line(MARGIN, y, PAGE_WIDTH - MARGIN, y)
        y -= ROW_HEIGHT
        pdf.setFont("Helvetica-Bold", 10)
        pdf.drawRightString(PAGE_WIDTH - MARGIN, y, f"GRAND TOTAL: {total_amount}")

    def draw_footer():
        """Draws the footer section."""
        pdf.setFont("Helvetica", 10)
        pdf.drawRightString(PAGE_WIDTH - MARGIN, FOOTER_HEIGHT, "AUTHORISED SIGN")

    draw_border()
    draw_header()
    draw_table()
    draw_footer()

    pdf.save()
    buffer.seek(0)

    # Save the file to Google Drive
    folder_id = create_drive_folder("Sales Invoice")  # Create/Get "Sales Invoice" folder
    filename = f"Invoice_{buyer_name}_{formatted_date}.pdf"
    upload_to_drive(folder_id, filename, buffer)

    # Return the file as a response
    buffer.seek(0)  # Reset buffer pointer for sending
    return send_file(buffer, as_attachment=True, download_name=filename, mimetype="application/pdf")
if __name__ == "__main__":
    app.run(debug=True)
